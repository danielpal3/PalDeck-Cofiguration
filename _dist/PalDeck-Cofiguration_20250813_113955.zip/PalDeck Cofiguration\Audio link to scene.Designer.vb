﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Audio_link_to_scene
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        ComboBox1 = New ComboBox()
        CheckBox1 = New CheckBox()
        CheckBox2 = New CheckBox()
        CheckBox3 = New CheckBox()
        CheckBox4 = New CheckBox()
        CheckBox5 = New CheckBox()
        CheckBox6 = New CheckBox()
        CheckBox7 = New CheckBox()
        CheckBox8 = New CheckBox()
        CheckBox9 = New CheckBox()
        CheckBox10 = New CheckBox()
        CheckBox11 = New CheckBox()
        CheckBox12 = New CheckBox()
        CheckBox13 = New CheckBox()
        CheckBox14 = New CheckBox()
        CheckBox15 = New CheckBox()
        CheckBox16 = New CheckBox()
        CheckBox17 = New CheckBox()
        sav1 = New Button()
        Label3 = New Label()
        Button1 = New Button()
        ComboBox2 = New ComboBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(82, 15)
        Label1.TabIndex = 0
        Label1.Text = "Audio sources"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(304, 9)
        Label2.Name = "Label2"
        Label2.Size = New Size(38, 15)
        Label2.TabIndex = 1
        Label2.Text = "Scene"
        ' 
        ' ComboBox1
        ' 
        ComboBox1.FormattingEnabled = True
        ComboBox1.Location = New Point(304, 31)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(172, 23)
        ComboBox1.TabIndex = 2
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.Location = New Point(12, 31)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(84, 19)
        CheckBox1.TabIndex = 16
        CheckBox1.Text = "CheckBox1"
        CheckBox1.UseVisualStyleBackColor = True
        CheckBox1.Visible = False
        ' 
        ' CheckBox2
        ' 
        CheckBox2.AutoSize = True
        CheckBox2.Location = New Point(12, 56)
        CheckBox2.Name = "CheckBox2"
        CheckBox2.Size = New Size(84, 19)
        CheckBox2.TabIndex = 17
        CheckBox2.Text = "CheckBox2"
        CheckBox2.UseVisualStyleBackColor = True
        CheckBox2.Visible = False
        ' 
        ' CheckBox3
        ' 
        CheckBox3.AutoSize = True
        CheckBox3.Location = New Point(12, 81)
        CheckBox3.Name = "CheckBox3"
        CheckBox3.Size = New Size(84, 19)
        CheckBox3.TabIndex = 18
        CheckBox3.Text = "CheckBox3"
        CheckBox3.UseVisualStyleBackColor = True
        CheckBox3.Visible = False
        ' 
        ' CheckBox4
        ' 
        CheckBox4.AutoSize = True
        CheckBox4.Location = New Point(12, 106)
        CheckBox4.Name = "CheckBox4"
        CheckBox4.Size = New Size(84, 19)
        CheckBox4.TabIndex = 19
        CheckBox4.Text = "CheckBox4"
        CheckBox4.UseVisualStyleBackColor = True
        CheckBox4.Visible = False
        ' 
        ' CheckBox5
        ' 
        CheckBox5.AutoSize = True
        CheckBox5.Location = New Point(12, 131)
        CheckBox5.Name = "CheckBox5"
        CheckBox5.Size = New Size(84, 19)
        CheckBox5.TabIndex = 20
        CheckBox5.Text = "CheckBox5"
        CheckBox5.UseVisualStyleBackColor = True
        CheckBox5.Visible = False
        ' 
        ' CheckBox6
        ' 
        CheckBox6.AutoSize = True
        CheckBox6.Location = New Point(12, 156)
        CheckBox6.Name = "CheckBox6"
        CheckBox6.Size = New Size(84, 19)
        CheckBox6.TabIndex = 21
        CheckBox6.Text = "CheckBox6"
        CheckBox6.UseVisualStyleBackColor = True
        CheckBox6.Visible = False
        ' 
        ' CheckBox7
        ' 
        CheckBox7.AutoSize = True
        CheckBox7.Location = New Point(12, 181)
        CheckBox7.Name = "CheckBox7"
        CheckBox7.Size = New Size(84, 19)
        CheckBox7.TabIndex = 22
        CheckBox7.Text = "CheckBox7"
        CheckBox7.UseVisualStyleBackColor = True
        CheckBox7.Visible = False
        ' 
        ' CheckBox8
        ' 
        CheckBox8.AutoSize = True
        CheckBox8.Location = New Point(12, 206)
        CheckBox8.Name = "CheckBox8"
        CheckBox8.Size = New Size(84, 19)
        CheckBox8.TabIndex = 23
        CheckBox8.Text = "CheckBox8"
        CheckBox8.UseVisualStyleBackColor = True
        CheckBox8.Visible = False
        ' 
        ' CheckBox9
        ' 
        CheckBox9.AutoSize = True
        CheckBox9.Location = New Point(12, 231)
        CheckBox9.Name = "CheckBox9"
        CheckBox9.Size = New Size(84, 19)
        CheckBox9.TabIndex = 24
        CheckBox9.Text = "CheckBox9"
        CheckBox9.UseVisualStyleBackColor = True
        CheckBox9.Visible = False
        ' 
        ' CheckBox10
        ' 
        CheckBox10.AutoSize = True
        CheckBox10.Location = New Point(12, 256)
        CheckBox10.Name = "CheckBox10"
        CheckBox10.Size = New Size(90, 19)
        CheckBox10.TabIndex = 25
        CheckBox10.Text = "CheckBox10"
        CheckBox10.UseVisualStyleBackColor = True
        CheckBox10.Visible = False
        ' 
        ' CheckBox11
        ' 
        CheckBox11.AutoSize = True
        CheckBox11.Location = New Point(12, 281)
        CheckBox11.Name = "CheckBox11"
        CheckBox11.Size = New Size(90, 19)
        CheckBox11.TabIndex = 26
        CheckBox11.Text = "CheckBox11"
        CheckBox11.UseVisualStyleBackColor = True
        CheckBox11.Visible = False
        ' 
        ' CheckBox12
        ' 
        CheckBox12.AutoSize = True
        CheckBox12.Location = New Point(12, 306)
        CheckBox12.Name = "CheckBox12"
        CheckBox12.Size = New Size(90, 19)
        CheckBox12.TabIndex = 27
        CheckBox12.Text = "CheckBox12"
        CheckBox12.UseVisualStyleBackColor = True
        CheckBox12.Visible = False
        ' 
        ' CheckBox13
        ' 
        CheckBox13.AutoSize = True
        CheckBox13.Location = New Point(12, 331)
        CheckBox13.Name = "CheckBox13"
        CheckBox13.Size = New Size(90, 19)
        CheckBox13.TabIndex = 28
        CheckBox13.Text = "CheckBox13"
        CheckBox13.UseVisualStyleBackColor = True
        CheckBox13.Visible = False
        ' 
        ' CheckBox14
        ' 
        CheckBox14.AutoSize = True
        CheckBox14.Location = New Point(12, 356)
        CheckBox14.Name = "CheckBox14"
        CheckBox14.Size = New Size(90, 19)
        CheckBox14.TabIndex = 29
        CheckBox14.Text = "CheckBox14"
        CheckBox14.UseVisualStyleBackColor = True
        CheckBox14.Visible = False
        ' 
        ' CheckBox15
        ' 
        CheckBox15.AutoSize = True
        CheckBox15.Location = New Point(12, 381)
        CheckBox15.Name = "CheckBox15"
        CheckBox15.Size = New Size(90, 19)
        CheckBox15.TabIndex = 30
        CheckBox15.Text = "CheckBox15"
        CheckBox15.UseVisualStyleBackColor = True
        CheckBox15.Visible = False
        ' 
        ' CheckBox16
        ' 
        CheckBox16.AutoSize = True
        CheckBox16.Location = New Point(12, 406)
        CheckBox16.Name = "CheckBox16"
        CheckBox16.Size = New Size(90, 19)
        CheckBox16.TabIndex = 31
        CheckBox16.Text = "CheckBox16"
        CheckBox16.UseVisualStyleBackColor = True
        CheckBox16.Visible = False
        ' 
        ' CheckBox17
        ' 
        CheckBox17.AutoSize = True
        CheckBox17.Location = New Point(12, 431)
        CheckBox17.Name = "CheckBox17"
        CheckBox17.Size = New Size(90, 19)
        CheckBox17.TabIndex = 32
        CheckBox17.Text = "CheckBox17"
        CheckBox17.UseVisualStyleBackColor = True
        CheckBox17.Visible = False
        ' 
        ' sav1
        ' 
        sav1.Location = New Point(304, 60)
        sav1.Name = "sav1"
        sav1.Size = New Size(75, 23)
        sav1.TabIndex = 33
        sav1.Text = "Save"
        sav1.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(304, 86)
        Label3.Name = "Label3"
        Label3.Size = New Size(0, 15)
        Label3.TabIndex = 34
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(452, 172)
        Button1.Name = "Button1"
        Button1.Size = New Size(75, 23)
        Button1.TabIndex = 35
        Button1.Text = "Button1"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' ComboBox2
        ' 
        ComboBox2.FormattingEnabled = True
        ComboBox2.Location = New Point(678, 431)
        ComboBox2.Name = "ComboBox2"
        ComboBox2.Size = New Size(121, 23)
        ComboBox2.TabIndex = 36
        ComboBox2.Visible = False
        ' 
        ' Audio_link_to_scene
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 457)
        Controls.Add(ComboBox2)
        Controls.Add(Button1)
        Controls.Add(Label3)
        Controls.Add(sav1)
        Controls.Add(CheckBox17)
        Controls.Add(CheckBox16)
        Controls.Add(CheckBox15)
        Controls.Add(CheckBox14)
        Controls.Add(CheckBox13)
        Controls.Add(CheckBox12)
        Controls.Add(CheckBox11)
        Controls.Add(CheckBox10)
        Controls.Add(CheckBox9)
        Controls.Add(CheckBox8)
        Controls.Add(CheckBox7)
        Controls.Add(CheckBox6)
        Controls.Add(CheckBox5)
        Controls.Add(CheckBox4)
        Controls.Add(CheckBox3)
        Controls.Add(CheckBox2)
        Controls.Add(CheckBox1)
        Controls.Add(ComboBox1)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Audio_link_to_scene"
        Text = "Audio_link_to_scene"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents CheckBox7 As CheckBox
    Friend WithEvents CheckBox8 As CheckBox
    Friend WithEvents CheckBox9 As CheckBox
    Friend WithEvents CheckBox10 As CheckBox
    Friend WithEvents CheckBox11 As CheckBox
    Friend WithEvents CheckBox12 As CheckBox
    Friend WithEvents CheckBox13 As CheckBox
    Friend WithEvents CheckBox14 As CheckBox
    Friend WithEvents CheckBox15 As CheckBox
    Friend WithEvents CheckBox16 As CheckBox
    Friend WithEvents CheckBox17 As CheckBox
    Friend WithEvents sav1 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents ComboBox2 As ComboBox
End Class
